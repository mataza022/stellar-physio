import Link from "next/link";

const socials = [
  {
    name: "Facebook",
    href: "https://www.facebook.com/share/1J7ZdUji5t/?mibextid=wwXIfr",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
      </svg>
    ),
  },
  {
    name: "Instagram",
    href: "https://www.instagram.com/stellarphysioclinic",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
      </svg>
    ),
  },
  {
    name: "X (Twitter)",
    href: "https://x.com/physiostellar",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
      </svg>
    ),
  },
  {
    name: "TikTok",
    href: "https://www.tiktok.com/@stellar_physio",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
        <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
      </svg>
    ),
  },
  {
    name: "LinkedIn",
    href: "https://www.linkedin.com/in/stellar-physio-8b802a346",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.063 2.063 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
      </svg>
    ),
  },
  {
    name: "YouTube",
    href: "https://www.youtube.com/@stellarphysiokenya",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
        <path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
      </svg>
    ),
  },
];

const quickLinkServices = [
  { title: "General Consultations", href: "/services/general-consultations" },
  { title: "Chiropractor Services", href: "/services/chiropractor-services" },
  { title: "Physiotherapy", href: "/services/physiotherapy" },
  { title: "Home-Based Care", href: "/services/home-based-care" },
  { title: "Laboratory Services", href: "/services/stellar-laboratory-services" },
  { title: "Pharmacy", href: "/services/pharmacy" },
  { title: "Counselling Services", href: "/services/counselling-services" },
  { title: "Sports Massage", href: "/services/sports-massage" },
  { title: "Reflexology", href: "/services/reflexology" },
  { title: "Occupational Therapy", href: "/services/occupational-therapy" },
  { title: "Nutritional Services", href: "/services/nutritional-services" },
  { title: "Stretch & Exercise Therapy", href: "/services/stretch-exercise-therapy" },
];

const branchContacts = [
  {
    name: "Kenital Plaza, Ngong Road",
    phone: "+254 706 101 999",
    tel: "+254706101999",
  },
  {
    name: "Karen Country Club",
    phone: "+254 739 110 110",
    tel: "+254739110110",
  },
  {
    name: "Parklands Sports Club",
    phone: "+254 755 901 942",
    tel: "+254755901942",
  },
];

export default function Footer() {
  return (
    <footer className="bg-purple-dark text-white pt-16 pb-6 mt-20">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-10">
          {/* Newsletter + Socials */}
          <div>
            <h4 className="text-lg font-bold text-white mb-5">
              Subscribe to our Newsletter
            </h4>
            <p className="text-sm text-white/70 mb-4">
              Get the latest health tips and Stellar Physio updates delivered to
              your inbox.
            </p>
            <form className="flex w-full mb-6">
              <input
                type="email"
                placeholder="Your email address"
                className="flex-1 min-w-0 px-4 py-3 rounded-l bg-white text-gray-800 placeholder-gray-400 outline-none text-sm border border-white focus:border-green transition"
              />
              <button
                type="submit"
                className="bg-green text-white px-4 py-3 rounded-r font-semibold text-sm hover:bg-green-dark transition whitespace-nowrap"
              >
                Subscribe
              </button>
            </form>

            {/* Social Media Icons */}
            <div>
              <h5 className="text-sm font-bold text-white mb-3">Follow Us</h5>
              <div className="flex flex-wrap gap-3">
                {socials.map((s) => (
                  <a
                    key={s.name}
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={s.name}
                    title={s.name}
                    className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-green hover:scale-110 transition-all duration-200"
                  >
                    {s.icon}
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Contact Us — now with all branch numbers */}
          <div>
            <h4 className="text-lg font-bold text-white mb-5">Contact Us</h4>

            {/* Email — shared */}
            <div className="mb-4">
              <a
                href="mailto:info@stellarphysio.com"
                className="text-sm text-white/70 hover:text-green transition inline-flex items-center gap-2"
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-4 h-4 flex-shrink-0"
                >
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                  <polyline points="22,6 12,13 2,6" />
                </svg>
                info@stellarphysio.com
              </a>
            </div>

            {/* Branch phones */}
            <ul className="space-y-3 text-sm">
              {branchContacts.map((branch) => (
                <li key={branch.tel}>
                  <p className="text-white/50 text-xs mb-1">{branch.name}</p>
                  <a
                    href={`tel:${branch.tel}`}
                    className="text-white/80 hover:text-green transition inline-flex items-center gap-2 font-semibold"
                  >
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="w-4 h-4 flex-shrink-0"
                    >
                      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                    </svg>
                    {branch.phone}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links — all 12 services */}
          <div>
            <h4 className="text-lg font-bold text-white mb-5">Our Services</h4>
            <ul className="space-y-2 text-sm text-white/70">
              {quickLinkServices.map((service) => (
                <li key={service.href}>
                  <Link
                    href={service.href}
                    className="hover:text-green transition"
                  >
                    {service.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Dial A Physio */}
          <div>
            <p className="text-sm text-white/70 mb-4">
              Call us directly to book a session or for urgent enquiries.
            </p>
            <a
              href="tel:+254719881291"
              className="inline-block hover:opacity-90 transition"
              aria-label="Dial A Physio — Call 0719 881 291"
            >
              <img
                src="/images/dialaphysio.png"
                alt="Dial A Physio — Call 0719 881 291"
                className="h-50 w-auto"
              />
            </a>
          </div>
        </div>

        <div className="border-t border-white/10 pt-6 text-center text-xs text-white/50">
          <p>
            &copy; {new Date().getFullYear()} Stellar Physio. All rights
            reserved. Created by{" "}
            <span className="underline hover:text-green cursor-pointer">
              Webora Digital Solutions
            </span>
          </p>
        </div>
      </div>
    </footer>
  );
}